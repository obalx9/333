/*
  # Create users table with RLS policies

  1. New Tables
    - `users`
      - `id` (text, primary key) - Telegram user ID
      - `username` (text, nullable) - Telegram username
      - `is_activated` (boolean) - Whether user is activated by admin
      - `is_subscribed` (boolean) - Whether user has active subscription
      - `subscription_expires` (timestamptz) - When subscription expires
      - `balance` (integer) - User balance in cents
      - `referral_code` (text, unique) - Unique referral code
      - `referred_by` (text) - ID of referring user
      - `referral_count` (integer) - Number of referrals
      - `created_at` (timestamptz) - When user was created

  2. Security
    - Enable RLS on users table
    - Add policies for:
      - Public insert (for initial user creation)
      - Public select (for referral lookups)
      - Authenticated update (for user data updates)
*/

-- Create users table
CREATE TABLE public.users (
  id text PRIMARY KEY,
  username text,
  is_activated boolean DEFAULT false NOT NULL,
  is_subscribed boolean DEFAULT false NOT NULL,
  subscription_expires timestamptz,
  balance integer DEFAULT 0 NOT NULL,
  referral_code text UNIQUE,
  referred_by text REFERENCES public.users(id),
  referral_count integer DEFAULT 0 NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL
);

-- Create indexes
CREATE INDEX users_username_idx ON public.users(username);
CREATE INDEX users_referral_code_idx ON public.users(referral_code);
CREATE INDEX users_referred_by_idx ON public.users(referred_by);

-- Enable Row Level Security
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public insert" ON public.users
  FOR INSERT TO public
  WITH CHECK (true);

CREATE POLICY "Allow public select" ON public.users
  FOR SELECT TO public
  USING (true);

CREATE POLICY "Allow update own data" ON public.users
  FOR UPDATE TO public
  USING (true)
  WITH CHECK (true);