/*
  # Update users table schema

  1. Changes
    - Use UUID for primary key and foreign keys
    - Add proper constraints and defaults
    - Update RLS policies for proper auth handling
    - Add indexes for performance

  2. Columns
    - `id` (uuid, primary key) - Internal unique identifier
    - `telegram_id` (text, not null) - Telegram user ID
    - `username` (text) - Telegram username
    - `is_activated` (boolean) - Admin activation status
    - `is_subscribed` (boolean) - Subscription status
    - `subscription_expires` (timestamptz) - When subscription ends
    - `balance` (integer) - User's balance
    - `referral_code` (text) - Unique referral code
    - `referred_by` (uuid) - Reference to referring user
    - `referral_count` (integer) - Number of referrals
    - `created_at` (timestamptz) - Account creation timestamp

  3. Security
    - Enable RLS
    - Add policies for public and authenticated access
    - Use auth.uid() for user identification
*/

-- Create extension if not exists
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Recreate users table with proper structure
CREATE TABLE IF NOT EXISTS public.users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  telegram_id text NOT NULL UNIQUE,
  username text,
  is_activated boolean DEFAULT false,
  is_subscribed boolean DEFAULT false,
  subscription_expires timestamptz,
  balance integer DEFAULT 0,
  referral_code text UNIQUE,
  referred_by uuid REFERENCES public.users(id),
  referral_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any
DROP POLICY IF EXISTS "Allow insert access to users" ON public.users;
DROP POLICY IF EXISTS "Allow read access to users" ON public.users;
DROP POLICY IF EXISTS "Allow users to update their own data" ON public.users;
DROP POLICY IF EXISTS "Public can create users" ON public.users;
DROP POLICY IF EXISTS "Users can read own data" ON public.users;
DROP POLICY IF EXISTS "Users can update own data" ON public.users;

-- Create new policies
CREATE POLICY "Public can read basic user info"
  ON public.users
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can update own data"
  ON public.users
  FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

CREATE POLICY "Allow insert for new users"
  ON public.users
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS users_telegram_id_idx ON public.users (telegram_id);
CREATE INDEX IF NOT EXISTS users_referral_code_idx ON public.users (referral_code);
CREATE INDEX IF NOT EXISTS users_referred_by_idx ON public.users (referred_by);

-- Add helpful comments
COMMENT ON TABLE public.users IS 'User profiles for the referral program';
COMMENT ON COLUMN public.users.id IS 'Primary key - internal UUID';
COMMENT ON COLUMN public.users.telegram_id IS 'Telegram user ID - used for authentication';
COMMENT ON COLUMN public.users.is_activated IS 'Whether the user has been activated by admin';
COMMENT ON COLUMN public.users.is_subscribed IS 'Whether the user has an active subscription';
COMMENT ON COLUMN public.users.subscription_expires IS 'When the subscription expires';
COMMENT ON COLUMN public.users.balance IS 'User balance in cents';
COMMENT ON COLUMN public.users.referral_code IS 'Unique referral code for this user';
COMMENT ON COLUMN public.users.referred_by IS 'UUID of the user who referred this user';
COMMENT ON COLUMN public.users.referral_count IS 'Number of users referred by this user';