/*
  # Create users table with Telegram integration

  1. Changes
    - Use text ID (Telegram user ID) as primary key
    - Add proper constraints and defaults
    - Update RLS policies to use ID directly
    - Add indexes for performance

  2. Columns
    - `id` (text, primary key) - Telegram user ID
    - `username` (text) - Telegram username
    - `is_activated` (boolean) - Admin activation status
    - `is_subscribed` (boolean) - Subscription status
    - `subscription_expires` (timestamptz) - When subscription ends
    - `balance` (integer) - User's balance
    - `referral_code` (text) - Unique referral code
    - `referred_by` (text) - Reference to referring user
    - `referral_count` (integer) - Number of referrals
    - `created_at` (timestamptz) - Account creation timestamp

  3. Security
    - Enable RLS
    - Add policies for public and authenticated access
    - Use direct ID comparison in policies
*/

-- Create users table with proper structure
CREATE TABLE IF NOT EXISTS public.users (
  id text PRIMARY KEY,
  username text,
  is_activated boolean DEFAULT false,
  is_subscribed boolean DEFAULT false,
  subscription_expires timestamptz,
  balance integer DEFAULT 0,
  referral_code text UNIQUE,
  referred_by text REFERENCES public.users(id),
  referral_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any
DROP POLICY IF EXISTS "Allow insert access to users" ON public.users;
DROP POLICY IF EXISTS "Allow read access to users" ON public.users;
DROP POLICY IF EXISTS "Allow users to update their own data" ON public.users;
DROP POLICY IF EXISTS "Public can create users" ON public.users;
DROP POLICY IF EXISTS "Users can read own data" ON public.users;
DROP POLICY IF EXISTS "Users can update own data" ON public.users;

-- Create new policies with proper ID handling
CREATE POLICY "Public can read basic user info"
  ON public.users
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can update own data"
  ON public.users
  FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

CREATE POLICY "Allow insert for new users"
  ON public.users
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS users_username_idx ON public.users (username);
CREATE INDEX IF NOT EXISTS users_referral_code_idx ON public.users (referral_code);
CREATE INDEX IF NOT EXISTS users_referred_by_idx ON public.users (referred_by);

-- Add helpful comments
COMMENT ON TABLE public.users IS 'User profiles for the referral program';
COMMENT ON COLUMN public.users.id IS 'Primary key - Telegram user ID';
COMMENT ON COLUMN public.users.username IS 'Telegram username';
COMMENT ON COLUMN public.users.is_activated IS 'Whether the user has been activated by admin';
COMMENT ON COLUMN public.users.is_subscribed IS 'Whether the user has an active subscription';
COMMENT ON COLUMN public.users.subscription_expires IS 'When the subscription expires';
COMMENT ON COLUMN public.users.balance IS 'User balance in cents';
COMMENT ON COLUMN public.users.referral_code IS 'Unique referral code for this user';
COMMENT ON COLUMN public.users.referred_by IS 'ID of the user who referred this user';
COMMENT ON COLUMN public.users.referral_count IS 'Number of users referred by this user';