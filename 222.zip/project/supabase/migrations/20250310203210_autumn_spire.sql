/*
  # Update users table schema

  1. Changes
    - Add missing columns
    - Update column types and defaults
    - Add proper constraints
    - Update RLS policies

  2. New Columns
    - `telegram_id` (text, not null) - Telegram user ID
    - `is_activated` (boolean) - User activation status
    - `subscription_expires` (timestamptz) - Subscription expiration date
    - `balance` (integer) - User's balance in cents
    - `referral_count` (integer) - Number of referrals

  3. Security
    - Enable RLS
    - Add policies for authenticated users
    - Add policies for public access
*/

-- Recreate users table with proper structure
CREATE TABLE IF NOT EXISTS public.users (
  id text PRIMARY KEY,
  telegram_id text NOT NULL,
  username text,
  is_activated boolean DEFAULT false,
  is_subscribed boolean DEFAULT false,
  subscription_expires timestamptz,
  balance integer DEFAULT 0,
  referral_code text UNIQUE,
  referred_by text REFERENCES public.users(id),
  referral_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if any
DROP POLICY IF EXISTS "Allow insert access to users" ON public.users;
DROP POLICY IF EXISTS "Allow read access to users" ON public.users;
DROP POLICY IF EXISTS "Allow users to update their own data" ON public.users;
DROP POLICY IF EXISTS "Public can create users" ON public.users;
DROP POLICY IF EXISTS "Users can read own data" ON public.users;
DROP POLICY IF EXISTS "Users can update own data" ON public.users;

-- Create new policies
CREATE POLICY "Public can read basic user info"
  ON public.users
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can update own data"
  ON public.users
  FOR UPDATE
  TO public
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

CREATE POLICY "Allow insert for new users"
  ON public.users
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create indexes
CREATE INDEX IF NOT EXISTS users_telegram_id_idx ON public.users (telegram_id);
CREATE INDEX IF NOT EXISTS users_referral_code_idx ON public.users (referral_code);
CREATE INDEX IF NOT EXISTS users_referred_by_idx ON public.users (referred_by);

-- Add comments
COMMENT ON TABLE public.users IS 'User profiles for the referral program';
COMMENT ON COLUMN public.users.id IS 'Primary key - matches Telegram user ID';
COMMENT ON COLUMN public.users.telegram_id IS 'Telegram user ID';
COMMENT ON COLUMN public.users.is_activated IS 'Whether the user has been activated by admin';
COMMENT ON COLUMN public.users.is_subscribed IS 'Whether the user has an active subscription';
COMMENT ON COLUMN public.users.subscription_expires IS 'When the subscription expires';
COMMENT ON COLUMN public.users.balance IS 'User balance in cents';
COMMENT ON COLUMN public.users.referral_code IS 'Unique referral code for this user';
COMMENT ON COLUMN public.users.referred_by IS 'ID of the user who referred this user';
COMMENT ON COLUMN public.users.referral_count IS 'Number of users referred by this user';