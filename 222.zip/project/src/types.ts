export interface User {
  telegramId: string;
  username?: string;
  isSubscribed: boolean;
  referralCode: string;
  referredBy?: string;
  referralCount: number;
  bonusAmount: number;
  joinDate: Date;
}

export interface ReferralStats {
  totalReferrals: number;
  activeReferrals: number;
  totalBonus: number;
}