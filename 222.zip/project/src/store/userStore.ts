import { create } from 'zustand';
import { supabase } from '../lib/supabase';
import { getUserData, initTelegram } from '../lib/telegram';

interface UserState {
  id: string | null;
  username: string | null;
  isSubscribed: boolean;
  referralCode: string | null;
  balance: number;
  loading: boolean;
  error: string | null;
  fetchUser: () => Promise<void>;
  updateUser: (data: Partial<UserState>) => Promise<void>;
  startPolling: () => void;
  stopPolling: () => void;
}

export const useUserStore = create<UserState>((set, get) => {
  let pollingInterval: NodeJS.Timeout | null = null;
  let retryCount = 0;
  const MAX_RETRIES = 3;
  const RETRY_DELAY = 1000;
  const POLLING_INTERVAL = 5000;

  const generateReferralCode = () => {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
  };

  const createUser = async (telegramUser: { id: string; username: string | null }) => {
    console.log('Creating new user:', telegramUser);

    const newUserData = {
      id: telegramUser.id,
      username: telegramUser.username,
      is_subscribed: false,
      is_activated: false,
      balance: 0,
      referral_code: generateReferralCode(),
      created_at: new Date().toISOString()
    };

    try {
      const { data: newUser, error } = await supabase
        .from('users')
        .upsert([newUserData], {
          onConflict: 'id',
          ignoreDuplicates: false
        })
        .select()
        .single();

      if (error) throw error;

      console.log('Successfully created/updated user:', newUser);
      return newUser;
    } catch (error) {
      console.error('Error in createUser:', error);
      throw error;
    }
  };

  const fetchUserData = async () => {
    try {
      // Initialize Telegram Web App
      const initialized = initTelegram();
      if (!initialized) {
        throw new Error('Failed to initialize Telegram Web App');
      }

      const telegramUser = getUserData();
      if (!telegramUser?.id) {
        throw new Error('No Telegram user ID available');
      }

      // Always try to create/update user first
      const user = await createUser(telegramUser);

      return {
        id: user.id,
        username: user.username,
        isSubscribed: Boolean(user.is_subscribed || user.is_activated),
        referralCode: user.referral_code,
        balance: user.balance || 0
      };
    } catch (error) {
      console.error('Error in fetchUserData:', error);
      throw error;
    }
  };

  return {
    id: null,
    username: null,
    isSubscribed: false,
    referralCode: null,
    balance: 0,
    loading: false,
    error: null,

    fetchUser: async () => {
      if (get().loading) return;

      set({ loading: true, error: null });
      
      try {
        const userData = await fetchUserData();
        set({
          ...userData,
          loading: false,
          error: null
        });
        retryCount = 0;
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
        console.error('Error fetching user:', error);
        
        if (retryCount < MAX_RETRIES) {
          retryCount++;
          setTimeout(() => get().fetchUser(), RETRY_DELAY);
        } else {
          set({ 
            loading: false,
            error: errorMessage
          });
        }
      }
    },

    updateUser: async (data) => {
      const currentId = get().id;
      if (!currentId) return;

      try {
        const { error } = await supabase
          .from('users')
          .update(data)
          .eq('id', currentId);

        if (error) throw error;
        await get().fetchUser();
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
        set({ error: errorMessage });
      }
    },

    startPolling: () => {
      if (pollingInterval) {
        clearInterval(pollingInterval);
      }

      // Initial fetch
      get().fetchUser();

      // Start polling
      pollingInterval = setInterval(() => {
        get().fetchUser();
      }, POLLING_INTERVAL);
    },

    stopPolling: () => {
      if (pollingInterval) {
        clearInterval(pollingInterval);
        pollingInterval = null;
      }
    }
  };
});