const TelegramBot = require('node-telegram-bot-api');
const dotenv = require('dotenv');
const { createClient } = require('@supabase/supabase-js');

// Load environment variables
dotenv.config();

// Validate required environment variables
const requiredEnvVars = ['MAIN_BOT_TOKEN', 'ADMIN_BOT_TOKEN', 'ADMIN_CHAT_ID', 'VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY'];
for (const envVar of requiredEnvVars) {
  if (!process.env[envVar]) {
    console.error(`Missing required environment variable: ${envVar}`);
    process.exit(1);
  }
}

// Initialize bots with error handling
let bot;
let adminBot;

try {
  bot = new TelegramBot(process.env.MAIN_BOT_TOKEN, { 
    polling: true,
    filepath: false // Disable file downloading
  });
  
  adminBot = new TelegramBot(process.env.ADMIN_BOT_TOKEN);
  
  console.log('Main bot initialized successfully');
} catch (error) {
  console.error('Failed to initialize bots:', error);
  process.exit(1);
}

// Initialize Supabase
const supabase = createClient(
  process.env.VITE_SUPABASE_URL,
  process.env.VITE_SUPABASE_ANON_KEY
);

// Error handling for polling errors
bot.on('polling_error', (error) => {
  console.error('Polling error:', error);
});

bot.on('error', (error) => {
  console.error('Bot error:', error);
});

// Команда /start
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const username = msg.from.username;
  
  const welcomeMessage = `
Привет${username ? `, @${username}` : ''}! 👋

Добро пожаловать в нашу реферальную программу!

🔹 Получайте бонусы за приглашенных друзей
🔹 Следите за статистикой в реальном времени
🔹 Выводите заработанные средства
  `;
  
  const webAppButton = {
    reply_markup: {
      keyboard: [[{
        text: '🚀 Открыть приложение',
        web_app: { url: 'https://incomparable-narwhal-19eb62.netlify.app' }
      }]],
      resize_keyboard: true
    }
  };
  
  try {
    await bot.sendMessage(chatId, welcomeMessage, webAppButton);
    console.log('Welcome message sent to:', chatId);
  } catch (error) {
    console.error('Error sending welcome message:', error);
  }
});

// Обработчик данных от веб-приложения
bot.on('message', async (msg) => {
  if (msg.web_app_data) {
    const chatId = msg.chat.id;
    const data = msg.web_app_data.data;

    try {
      if (data === '/subscribe') {
        const subscriptionPrice = process.env.SUBSCRIPTION_PRICE || '999';
        const paymentMessage = `
💳 Для оформления подписки:

1. Переведите ${subscriptionPrice}₽ на карту:
   1234 5678 9012 3456

2. В комментарии к переводу укажите ваш ID: ${msg.from.id}

3. После оплаты нажмите кнопку "Я оплатил"

После проверки оплаты вы получите доступ к реферальной программе.
        `;

        const paymentButtons = {
          reply_markup: {
            inline_keyboard: [[
              { text: '💰 Я оплатил', callback_data: `payment_confirmed_${msg.from.id}` }
            ]]
          }
        };

        await bot.sendMessage(chatId, paymentMessage, paymentButtons);
        console.log('Payment message sent to:', chatId);
      }
    } catch (error) {
      console.error('Error processing web_app_data:', error);
      await bot.sendMessage(chatId, 'Произошла ошибка. Пожалуйста, попробуйте позже.');
    }
  }
});

// Обработка нажатия кнопки "Я оплатил"
bot.on('callback_query', async (query) => {
  const callbackData = query.data;
  
  if (callbackData.startsWith('payment_confirmed_')) {
    try {
      await bot.answerCallbackQuery(query.id);
      
      const userId = query.from.id;
      const username = query.from.username;

      // Отправляем уведомление админу через админ-бота
      const adminMessage = `
📱 Новая заявка на подписку:

👤 Пользователь: ${username ? '@' + username : 'Без username'}
🆔 ID: ${userId}
💰 Сумма: ${process.env.SUBSCRIPTION_PRICE}₽
      `;

      const adminButtons = {
        reply_markup: {
          inline_keyboard: [
            [
              { text: '✅ Подтвердить', callback_data: `confirm_${userId}` },
              { text: '❌ Отклонить', callback_data: `reject_${userId}` }
            ]
          ]
        }
      };

      await adminBot.sendMessage(process.env.ADMIN_CHAT_ID, adminMessage, adminButtons);
      console.log('Admin notification sent for user:', userId);
      
      // Отправляем сообщение пользователю
      await bot.sendMessage(userId, `
✅ Ваша заявка на оплату отправлена администратору

Пожалуйста, ожидайте подтверждения. Мы уведомим вас, когда подписка будет активирована.
      `);

    } catch (error) {
      console.error('Error processing payment confirmation:', error);
      await bot.sendMessage(query.from.id, 'Произошла ошибка при обработке платежа. Пожалуйста, попробуйте позже или обратитесь в поддержку.');
    }
  }
});

console.log('Main bot started and listening...');