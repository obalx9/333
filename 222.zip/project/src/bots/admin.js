const TelegramBot = require('node-telegram-bot-api');
const dotenv = require('dotenv');
const { createClient } = require('@supabase/supabase-js');

// Load environment variables
dotenv.config();

// Validate required environment variables
const requiredEnvVars = ['ADMIN_BOT_TOKEN', 'MAIN_BOT_TOKEN', 'ADMIN_CHAT_ID', 'VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY'];
for (const envVar of requiredEnvVars) {
  if (!process.env[envVar]) {
    console.error(`Missing required environment variable: ${envVar}`);
    process.exit(1);
  }
}

// Initialize bots with error handling
let bot;
let mainBot;

try {
  bot = new TelegramBot(process.env.ADMIN_BOT_TOKEN, { 
    polling: true,
    filepath: false // Disable file downloading
  });
  
  mainBot = new TelegramBot(process.env.MAIN_BOT_TOKEN);
  
  console.log('Admin bot initialized successfully');
} catch (error) {
  console.error('Failed to initialize bots:', error);
  process.exit(1);
}

// Initialize Supabase with retries
const initSupabase = (retries = 3, delay = 1000) => {
  let attempt = 0;
  
  const connect = async () => {
    try {
      const supabase = createClient(
        process.env.VITE_SUPABASE_URL,
        process.env.VITE_SUPABASE_ANON_KEY,
        {
          auth: {
            autoRefreshToken: true,
            persistSession: false
          }
        }
      );

      // Test the connection
      const { error } = await supabase.from('users').select('id').limit(1);
      if (error) throw error;

      console.log('Supabase connection established successfully');
      return supabase;
    } catch (error) {
      attempt++;
      console.error(`Supabase connection attempt ${attempt} failed:`, error);
      
      if (attempt >= retries) {
        throw new Error(`Failed to connect to Supabase after ${retries} attempts`);
      }
      
      await new Promise(resolve => setTimeout(resolve, delay));
      return connect();
    }
  };

  return connect();
};

// Initialize Supabase with retries
let supabase;
initSupabase()
  .then(client => {
    supabase = client;
  })
  .catch(error => {
    console.error('Fatal: Failed to initialize Supabase:', error);
    process.exit(1);
  });

// Error handling for polling errors
bot.on('polling_error', (error) => {
  console.error('Polling error:', error);
});

bot.on('error', (error) => {
  console.error('Bot error:', error);
});

// Обработка старта админ-бота
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  try {
    await bot.sendMessage(chatId, `
👋 Привет! Это админ-бот для управления подписками.

Здесь вы будете получать уведомления о новых заявках на подписку и сможете их обрабатывать.

ID чата: ${chatId}
    `);
    console.log('Admin start message sent to:', chatId);
  } catch (error) {
    console.error('Error sending start message:', error);
  }
});

// Helper function to verify subscription update with retries
async function verifySubscriptionUpdate(userId, maxRetries = 3, delay = 1000) {
  for (let i = 0; i < maxRetries; i++) {
    console.log(`Verifying subscription update (attempt ${i + 1}/${maxRetries})`);
    
    // Wait for the specified delay
    await new Promise(resolve => setTimeout(resolve, delay));
    
    const { data: user, error } = await supabase
      .from('users')
      .select('is_activated, is_subscribed, subscription_expires')
      .eq('id', userId)
      .single();
    
    if (error) {
      console.error('Error verifying subscription:', error);
      continue;
    }
    
    console.log('Verification check result:', user);
    
    // Check both is_activated and is_subscribed fields
    if (user && (user.is_activated || user.is_subscribed) && user.subscription_expires) {
      console.log('Subscription verified successfully');
      return true;
    }
    
    console.log('Verification failed, will retry if attempts remain');
  }
  
  return false;
}

// Обработка нажатий на кнопки
bot.on('callback_query', async (query) => {
  const chatId = query.message.chat.id;
  
  if (chatId.toString() !== process.env.ADMIN_CHAT_ID) {
    console.warn('Unauthorized callback query from:', chatId);
    return;
  }

  try {
    const [action, userId] = query.data.split('_');
    
    if (action === 'confirm') {
      console.log('Processing confirmation for user:', userId);

      // First, check if the user exists
      const { data: user, error: checkError } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (checkError) {
        console.error('Error checking user:', checkError);
        throw new Error('Error checking user status');
      }

      if (!user) {
        console.log('User not found, trying to create...');
        // Try to create the user if they don't exist
        const { data: newUser, error: createError } = await supabase
          .from('users')
          .insert([{
            id: userId,
            is_activated: false,
            is_subscribed: false,
            balance: 0,
            referral_code: Math.random().toString(36).substring(2, 8).toUpperCase()
          }])
          .select()
          .single();

        if (createError) {
          console.error('Error creating user:', createError);
          throw new Error('Failed to create user');
        }

        console.log('Created new user:', newUser);
      }

      // Update user subscription
      const { error: updateError } = await supabase
        .from('users')
        .update({
          is_activated: true,
          is_subscribed: true,
          subscription_expires: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
        })
        .eq('id', userId);

      if (updateError) {
        console.error('Error updating user subscription:', updateError);
        throw new Error('Failed to update subscription status');
      }

      console.log('Successfully updated user subscription');

      // Verify the update with retries
      const isVerified = await verifySubscriptionUpdate(userId);

      if (!isVerified) {
        throw new Error('Failed to verify subscription update after multiple attempts');
      }

      // Отправляем сообщение пользователю
      await mainBot.sendMessage(userId, `
🎉 Поздравляем! Ваша подписка активирована!

Теперь вам доступны все функции реферальной программы:
- Создание реферальных ссылок
- Получение бонусов за рефералов
- Статистика и аналитика
- Вывод средств
      `);

      // Обновляем сообщение в админ-чате
      await bot.editMessageText(
        '✅ Платеж подтвержден\n\nПодписка успешно активирована',
        {
          chat_id: chatId,
          message_id: query.message.message_id
        }
      );
      
      console.log('Payment confirmed for user:', userId);
    } 
    else if (action === 'reject') {
      // Отправляем сообщение пользователю
      await mainBot.sendMessage(userId, `
❌ К сожалению, оплата не подтверждена

Возможные причины:
- Неверная сумма перевода
- Отсутствие ID в комментарии
- Перевод на неверные реквизиты

Пожалуйста, проверьте правильность перевода и попробуйте снова.
Если вы уверены, что всё сделали правильно, напишите в поддержку.
      `);

      // Обновляем сообщение в админ-чате
      await bot.editMessageText(
        '❌ Платеж отклонен\n\nПользователь уведомлен',
        {
          chat_id: chatId,
          message_id: query.message.message_id
        }
      );
      
      console.log('Payment rejected for user:', userId);
    }

    // Отвечаем на callback query
    await bot.answerCallbackQuery(query.id);

  } catch (error) {
    console.error('Error processing callback query:', error);
    
    // Отправляем более информативное сообщение об ошибке
    const errorMessage = error.message || 'Неизвестная ошибка';
    await bot.sendMessage(chatId, `
❌ Ошибка при обработке действия:
${errorMessage}

Пожалуйста, попробуйте еще раз или проверьте логи.
    `);
    
    // Отвечаем на callback query, чтобы убрать загрузку с кнопки
    await bot.answerCallbackQuery(query.id, {
      text: 'Произошла ошибка при обработке запроса'
    });
  }
});

console.log('Admin bot started and listening...');