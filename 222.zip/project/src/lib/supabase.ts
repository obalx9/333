import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export async function createUser(telegramId: string, username?: string) {
  const referralCode = Math.random().toString(36).substring(2, 10).toUpperCase();
  
  const { data, error } = await supabase
    .from('users')
    .insert([
      {
        telegram_id: telegramId,
        username,
        referral_code: referralCode
      }
    ])
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function getUserByTelegramId(telegramId: string) {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('telegram_id', telegramId)
    .single();

  if (error) throw error;
  return data;
}

export async function updateUserSubscription(userId: string, expirationDate: Date) {
  const { data, error } = await supabase
    .from('users')
    .update({
      is_subscribed: true,
      subscription_expires: expirationDate.toISOString()
    })
    .eq('id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function addReferralBonus(userId: string, amount: number) {
  const { data, error } = await supabase
    .from('users')
    .update({
      bonus_amount: supabase.rpc('increment_bonus', { amount })
    })
    .eq('id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
}