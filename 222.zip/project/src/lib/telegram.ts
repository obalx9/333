import WebApp from '@twa-dev/sdk';

export const telegram = WebApp;

export function initTelegram() {
  try {
    // Check if we're in development environment
    const isDev = import.meta.env.DEV;
    
    // In development, we'll mock Telegram WebApp properly
    if (isDev) {
      if (typeof window !== 'undefined') {
        // Create full mock of Telegram WebApp
        window.Telegram = {
          WebApp: {
            initData: '',
            initDataUnsafe: {
              user: {
                id: '123456789',
                username: 'test_user',
                first_name: 'Test',
                last_name: 'User'
              }
            },
            ready: () => {},
            expand: () => {},
            close: () => {},
            isExpanded: true,
            MainButton: {
              text: '',
              color: '#000000',
              textColor: '#ffffff',
              isVisible: false,
              isActive: true,
              isProgressVisible: false,
              setText: (text: string) => {},
              onClick: (callback: () => void) => {},
              offClick: (callback: () => void) => {},
              show: () => {},
              hide: () => {},
              enable: () => {},
              disable: () => {},
              showProgress: (leaveActive: boolean) => {},
              hideProgress: () => {},
              setParams: (params: any) => {}
            }
          }
        };
        
        console.log('Development mode: Telegram WebApp mocked');
        return true;
      }
    }

    // For production, check if Telegram WebApp is available
    if (typeof window !== 'undefined' && window.Telegram?.WebApp) {
      if (!telegram.isExpanded) {
        telegram.expand();
      }
      console.log('Production mode: Telegram WebApp initialized');
      return true;
    }
    
    console.warn('Telegram Web App environment not detected');
    return false;
  } catch (error) {
    console.error('Error initializing Telegram Web App:', error);
    return false;
  }
}

export function getUserData() {
  try {
    // Check if we're in development environment
    const isDev = import.meta.env.DEV;
    
    if (isDev) {
      // Return consistent mock data in development
      const mockUser = {
        id: '123456789',
        username: 'test_user',
        firstName: 'Test',
        lastName: 'User'
      };
      console.log('Development mode: Using mock user data:', mockUser);
      return mockUser;
    }

    // For production, get actual user data
    if (typeof window === 'undefined' || !window.Telegram?.WebApp?.initDataUnsafe?.user) {
      console.warn('User data not available in Telegram Web App');
      return null;
    }

    const user = window.Telegram.WebApp.initDataUnsafe.user;
    const userData = {
      id: user.id.toString(),
      username: user.username || null,
      firstName: user.first_name || null,
      lastName: user.last_name || null
    };
    
    console.log('Production mode: Got user data:', userData);
    return userData;
  } catch (error) {
    console.error('Error getting user data:', error);
    return null;
  }
}

export function showMainButton(text: string, onClick: () => void) {
  try {
    // In development, just log the action
    if (import.meta.env.DEV) {
      console.log('Development mode: Main button would show:', text);
      return;
    }

    if (typeof window === 'undefined' || !window.Telegram?.WebApp?.MainButton) {
      console.warn('Telegram MainButton not available');
      return;
    }

    const MainButton = window.Telegram.WebApp.MainButton;
    MainButton.setParams({
      text: text,
      color: '#2563eb',
      text_color: '#ffffff',
      is_active: true,
      is_visible: true
    });

    MainButton.offClick(onClick);
    MainButton.onClick(onClick);
    MainButton.show();
  } catch (error) {
    console.error('Error showing main button:', error);
  }
}

export function hideMainButton() {
  try {
    if (import.meta.env.DEV) {
      console.log('Development mode: Main button would hide');
      return;
    }

    if (typeof window !== 'undefined' && window.Telegram?.WebApp?.MainButton) {
      window.Telegram.WebApp.MainButton.hide();
    }
  } catch (error) {
    console.error('Error hiding main button:', error);
  }
}

export function expandApp() {
  try {
    if (import.meta.env.DEV) {
      console.log('Development mode: App would expand');
      return;
    }

    if (typeof window !== 'undefined' && window.Telegram?.WebApp && !window.Telegram.WebApp.isExpanded) {
      window.Telegram.WebApp.expand();
    }
  } catch (error) {
    console.error('Error expanding app:', error);
  }
}

export function closeApp() {
  try {
    if (import.meta.env.DEV) {
      console.log('Development mode: App would close');
      return;
    }

    if (typeof window !== 'undefined' && window.Telegram?.WebApp) {
      window.Telegram.WebApp.close();
    }
  } catch (error) {
    console.error('Error closing app:', error);
  }
}

// Add type definitions for window.Telegram
declare global {
  interface Window {
    Telegram?: {
      WebApp: {
        initData: string;
        initDataUnsafe: {
          user?: {
            id: number;
            username?: string;
            first_name?: string;
            last_name?: string;
          };
        };
        ready: () => void;
        expand: () => void;
        close: () => void;
        isExpanded: boolean;
        MainButton?: {
          text: string;
          color: string;
          textColor: string;
          isVisible: boolean;
          isActive: boolean;
          isProgressVisible: boolean;
          setText: (text: string) => void;
          onClick: (callback: () => void) => void;
          offClick: (callback: () => void) => void;
          show: () => void;
          hide: () => void;
          enable: () => void;
          disable: () => void;
          showProgress: (leaveActive: boolean) => void;
          hideProgress: () => void;
          setParams: (params: any) => void;
        };
      };
    };
  }
}