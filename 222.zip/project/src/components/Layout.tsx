import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, User, Users, CreditCard } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
}

function Layout({ children }: LayoutProps) {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      <div className="bg-[#111111] shadow-lg border-b border-[#222222]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <h1 className="text-2xl font-bold logo">.refinance</h1>
              </div>
            </div>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {children}
      </main>

      <nav className="fixed bottom-0 w-full bg-[#111111] border-t border-[#222222]">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-around py-3">
            <button
              onClick={() => navigate('/')}
              className="nav-item flex flex-col items-center text-gray-400 hover:text-blue-500"
            >
              <Home size={24} />
              <span className="text-xs mt-1">Главная</span>
            </button>
            <button
              onClick={() => navigate('/profile')}
              className="nav-item flex flex-col items-center text-gray-400 hover:text-blue-500"
            >
              <User size={24} />
              <span className="text-xs mt-1">Профиль</span>
            </button>
            <button
              onClick={() => navigate('/referrals')}
              className="nav-item flex flex-col items-center text-gray-400 hover:text-blue-500"
            >
              <Users size={24} />
              <span className="text-xs mt-1">Рефералы</span>
            </button>
            <button
              onClick={() => navigate('/subscribe')}
              className="nav-item flex flex-col items-center text-gray-400 hover:text-blue-500"
            >
              <CreditCard size={24} />
              <span className="text-xs mt-1">Подписка</span>
            </button>
          </div>
        </div>
      </nav>
    </div>
  );
}

export default Layout;