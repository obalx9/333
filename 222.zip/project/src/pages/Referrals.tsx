import React from 'react';
import { Users, TrendingUp, Share2 } from 'lucide-react';
import { useUserStore } from '../store/userStore';
import { useNavigate } from 'react-router-dom';

function Referrals() {
  const navigate = useNavigate();
  const { isSubscribed, balance, referralCode } = useUserStore();

  // Временные данные для демонстрации
  const stats = {
    totalReferrals: 0,
    activeReferrals: 0,
    totalEarnings: balance,
    conversionRate: 0
  };

  const referrals: Array<{
    id: number;
    username: string;
    status: string;
    date: string;
    earnings: number;
  }> = [];

  const handleShare = () => {
    if (!isSubscribed) {
      navigate('/subscribe');
      return;
    }

    if (referralCode) {
      navigator.clipboard.writeText(referralCode);
      // TODO: Показать уведомление о копировании
    }
  };

  if (!isSubscribed) {
    return (
      <div className="flex flex-col items-center justify-center h-[calc(100vh-16rem)]">
        <Users className="h-16 w-16 text-gray-400 mb-4" />
        <h3 className="text-xl font-medium text-white mb-2">
          Реферальная программа недоступна
        </h3>
        <p className="text-gray-400 mb-4 text-center">
          Для доступа к реферальной программе необходимо оформить подписку
        </p>
        <button
          onClick={() => navigate('/subscribe')}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-glow text-white bg-blue-600 hover:bg-blue-700"
        >
          Оформить подписку
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white/90">Рефералы</h2>
        <button
          onClick={handleShare}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-glow text-white bg-blue-600 hover:bg-blue-700"
        >
          <Share2 className="h-4 w-4 mr-2" />
          Пригласить
        </button>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <div className="glow-card rounded-lg overflow-hidden">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Users className="h-6 w-6 text-blue-500" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-400 truncate">
                    Всего рефералов
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-white">
                      {stats.totalReferrals}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="glow-card rounded-lg overflow-hidden">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Users className="h-6 w-6 text-blue-500" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-400 truncate">
                    Активные рефералы
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-white">
                      {stats.activeReferrals}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="glow-card rounded-lg overflow-hidden">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <TrendingUp className="h-6 w-6 text-blue-500" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-400 truncate">
                    Заработано
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-white">
                      {stats.totalEarnings}₽
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="glow-card rounded-lg overflow-hidden">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <TrendingUp className="h-6 w-6 text-blue-500" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-400 truncate">
                    Конверсия
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-white">
                      {stats.conversionRate}%
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      {referrals.length > 0 ? (
        <div className="glow-card rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-white mb-4">
              История рефералов
            </h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-[#222222]">
                <thead>
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Пользователь
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Статус
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Дата
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">
                      Заработано
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#222222]">
                  {referrals.map((referral) => (
                    <tr key={referral.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                        {referral.username}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                          referral.status === 'Активен' ? 'bg-blue-500/20 text-blue-400' : 'bg-gray-500/20 text-gray-400'
                        }`}>
                          {referral.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                        {referral.date}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                        {referral.earnings}₽
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <div className="glow-card rounded-lg p-6 text-center">
          <p className="text-gray-400">У вас пока нет рефералов</p>
        </div>
      )}
    </div>
  );
}

export default Referrals;