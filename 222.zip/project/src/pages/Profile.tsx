import React from 'react';
import { User, Settings, Copy } from 'lucide-react';
import { useUserStore } from '../store/userStore';

function Profile() {
  const { username, id, isSubscribed, referralCode } = useUserStore();

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // TODO: Показать уведомление о копировании
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white/90">Профиль</h2>

      <div className="glow-card rounded-lg divide-y divide-[#222222]">
        <div className="p-6">
          <div className="flex items-center">
            <div className="bg-blue-500/10 rounded-full p-3">
              <User className="h-6 w-6 text-blue-500" />
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-medium text-white">{username || 'Пользователь'}</h3>
              <p className="text-sm text-gray-400">ID: {id}</p>
            </div>
          </div>
        </div>

        <div className="p-6">
          <h4 className="text-sm font-medium text-gray-400">Подписка</h4>
          <div className="mt-2 flex justify-between items-center">
            <div>
              <p className="text-sm font-medium text-white">
                Статус: {isSubscribed ? 'Активна' : 'Неактивна'}
              </p>
              {isSubscribed && (
                <p className="text-sm text-gray-400">
                  Действует до: {new Date().toLocaleDateString('ru-RU')}
                </p>
              )}
            </div>
            <Settings className="h-5 w-5 text-gray-400" />
          </div>
        </div>

        <div className="p-6">
          <h4 className="text-sm font-medium text-gray-400">Реферальный код</h4>
          <div className="mt-2 flex justify-between items-center">
            <p className="text-sm font-medium text-white">{referralCode || 'Недоступен'}</p>
            {referralCode && (
              <button
                onClick={() => copyToClipboard(referralCode)}
                className="text-blue-500 hover:text-blue-400"
              >
                <Copy className="h-5 w-5" />
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="glow-card rounded-lg p-6">
        <h4 className="text-sm font-medium text-gray-400 mb-4">Настройки уведомлений</h4>
        <div className="space-y-4">
          <label className="flex items-center">
            <input
              type="checkbox"
              className="form-checkbox h-4 w-4 text-blue-500 bg-dark-300 border-[#222222] rounded"
              checked={isSubscribed}
              disabled={!isSubscribed}
            />
            <span className="ml-2 text-sm text-gray-300">Новые рефералы</span>
          </label>
          <label className="flex items-center">
            <input
              type="checkbox"
              className="form-checkbox h-4 w-4 text-blue-500 bg-dark-300 border-[#222222] rounded"
              checked={isSubscribed}
              disabled={!isSubscribed}
            />
            <span className="ml-2 text-sm text-gray-300">Начисление бонусов</span>
          </label>
        </div>
      </div>
    </div>
  );
}

export default Profile;