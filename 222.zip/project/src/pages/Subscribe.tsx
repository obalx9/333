import React, { useEffect, useState } from 'react';
import { CreditCard, CheckCircle, AlertCircle } from 'lucide-react';
import { showMainButton, getUserData, telegram } from '../lib/telegram';
import { useUserStore } from '../store/userStore';

function Subscribe() {
  const subscriptionPrice = 999;
  const [hasPaid, setHasPaid] = useState(false);
  const { id: userId } = useUserStore();
  
  const benefits = [
    'Доступ к реферальной программе',
    'Начисление бонусов за рефералов',
    'Статистика в реальном времени',
    'Вывод средств без комиссии',
    'Приоритетная поддержка'
  ];

  const handleSubscribe = () => {
    try {
      // Отправляем команду боту для получения инструкций по оплате
      telegram.sendData('/subscribe');
      setHasPaid(true);
    } catch (error) {
      console.error('Error sending data to bot:', error);
      window.alert('Произошла ошибка при отправке данных. Пожалуйста, попробуйте позже.');
    }
  };

  useEffect(() => {
    showMainButton('Оформить подписку', handleSubscribe);

    return () => {
      showMainButton('Оформить подписку', () => {});
    };
  }, []);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white/90">Подписка</h2>

      <div className="glow-card rounded-lg overflow-hidden">
        <div className="px-4 py-5 sm:p-6">
          <div className="text-center">
            <CreditCard className="mx-auto h-12 w-12 text-blue-500" />
            <h3 className="mt-2 text-xl font-semibold text-white">Премиум подписка</h3>
            <p className="mt-1 text-sm text-gray-400">Откройте полный доступ к реферальной программе</p>
          </div>

          <div className="mt-8">
            <div className="flex justify-center items-baseline">
              <span className="text-5xl font-extrabold text-white">{subscriptionPrice}</span>
              <span className="ml-1 text-2xl font-medium text-gray-400">₽</span>
              <span className="ml-2 text-gray-400">/месяц</span>
            </div>
          </div>

          <ul className="mt-8 space-y-4">
            {benefits.map((benefit, index) => (
              <li key={index} className="flex items-center">
                <CheckCircle className="h-5 w-5 text-blue-500" />
                <span className="ml-3 text-gray-300">{benefit}</span>
              </li>
            ))}
          </ul>

          <div className="mt-6 bg-[#111111] rounded-md p-4 border border-[#222222]">
            <div className="flex">
              <div className="flex-shrink-0">
                <AlertCircle className="h-5 w-5 text-blue-500" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-white">Процесс оплаты</h3>
                <div className="mt-2 text-sm text-gray-400">
                  <p>1. Нажмите кнопку "Оформить подписку"</p>
                  <p>2. Переведите {subscriptionPrice}₽ на карту</p>
                  <p>3. В комментарии к переводу укажите ваш ID: {userId}</p>
                  <p>4. Нажмите кнопку "Я оплатил" в боте</p>
                  <p>5. Ожидайте подтверждения от администратора</p>
                </div>
              </div>
            </div>
          </div>

          {hasPaid && (
            <div className="mt-6 bg-blue-500/10 rounded-md p-4 border border-blue-500/20">
              <div className="flex">
                <div className="flex-shrink-0">
                  <CheckCircle className="h-5 w-5 text-blue-500" />
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-white">Заявка отправлена</h3>
                  <p className="mt-1 text-sm text-gray-400">
                    Мы получили вашу заявку на оплату. Пожалуйста, ожидайте подтверждения от администратора.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Subscribe;