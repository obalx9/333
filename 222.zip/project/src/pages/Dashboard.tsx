import React from 'react';
import { ArrowUpRight, Users, Coins } from 'lucide-react';
import { useUserStore } from '../store/userStore';
import { useNavigate } from 'react-router-dom';

function Dashboard() {
  const navigate = useNavigate();
  const { isSubscribed, balance, referralCode } = useUserStore();

  const handleSubscribe = () => {
    navigate('/subscribe');
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white/90">Панель управления</h2>
      
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <div className="glow-card rounded-lg overflow-hidden">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Users className="h-6 w-6 text-blue-500" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-400 truncate">
                    Активные рефералы
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-white">0</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="glow-card rounded-lg overflow-hidden">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Coins className="h-6 w-6 text-blue-500" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-400 truncate">
                    Бонусы
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-white">{balance} ₽</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="glow-card rounded-lg overflow-hidden">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <ArrowUpRight className="h-6 w-6 text-blue-500" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-400 truncate">
                    Конверсия
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-white">0%</div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      {!isSubscribed && (
        <div className="glow-card rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-white">
              Статус подписки
            </h3>
            <div className="mt-2 max-w-xl text-sm text-gray-400">
              <p>
                Для доступа к реферальной программе необходимо оформить подписку
              </p>
            </div>
            <div className="mt-5">
              <button
                onClick={handleSubscribe}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-glow text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Оформить подписку
              </button>
            </div>
          </div>
        </div>
      )}

      {isSubscribed && referralCode && (
        <div className="glow-card rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-white">
              Ваш реферальный код
            </h3>
            <div className="mt-2">
              <p className="text-2xl font-mono font-bold text-blue-500">{referralCode}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Dashboard;