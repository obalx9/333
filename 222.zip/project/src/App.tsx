import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import Profile from './pages/Profile';
import Referrals from './pages/Referrals';
import Subscribe from './pages/Subscribe';
import { initTelegram, expandApp } from './lib/telegram';
import { useUserStore } from './store/userStore';

function App() {
  const { fetchUser, startPolling, stopPolling } = useUserStore();

  useEffect(() => {
    // Инициализируем Telegram Web App
    initTelegram();
    // Разворачиваем приложение на весь экран
    expandApp();
    // Загружаем данные пользователя
    fetchUser();
    // Запускаем polling
    startPolling();

    // Очистка при размонтировании
    return () => {
      stopPolling();
    };
  }, [fetchUser, startPolling, stopPolling]);

  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/referrals" element={<Referrals />} />
          <Route path="/subscribe" element={<Subscribe />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;