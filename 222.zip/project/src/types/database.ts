export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          telegram_id: string
          username: string | null
          is_subscribed: boolean
          subscription_expires: string | null
          referral_code: string
          referred_by: string | null
          bonus_amount: number
          created_at: string
        }
        Insert: {
          id?: string
          telegram_id: string
          username?: string | null
          is_subscribed?: boolean
          subscription_expires?: string | null
          referral_code: string
          referred_by?: string | null
          bonus_amount?: number
          created_at?: string
        }
        Update: {
          id?: string
          telegram_id?: string
          username?: string | null
          is_subscribed?: boolean
          subscription_expires?: string | null
          referral_code?: string
          referred_by?: string | null
          bonus_amount?: number
          created_at?: string
        }
      }
    }
  }
}